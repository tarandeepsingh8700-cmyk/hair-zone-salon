import React, { useState, useEffect } from 'react';
import { Award, Star, Users, Briefcase, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

export default function Stats() {
  const [reviews, setReviews] = useState(0);
  const [rating, setRating] = useState(0.0);
  const [clients, setClients] = useState(0);
  const [years, setYears] = useState(0);

  useEffect(() => {
    // Basic counting animation
    const duration = 1500; // milliseconds
    const steps = 60;
    const intervalTime = duration / steps;

    let step = 0;
    const timer = setInterval(() => {
      step++;
      
      // Values to reach:
      // Reviews: 172
      // Rating: 4.8
      // Clients: 1000
      // Years: 5

      setReviews(Math.min(172, Math.round((172 / steps) * step)));
      setRating(parseFloat(Math.min(4.8, (4.8 / steps) * step).toFixed(1)));
      setClients(Math.min(1000, Math.round((1000 / steps) * step)));
      setYears(Math.min(5, Math.round((5 / steps) * step)));

      if (step >= steps) {
        clearInterval(timer);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, []);

  const statsItems = [
    {
      label: 'Google Reviews',
      value: `${reviews}+`,
      sub: 'Highly Recommended',
      icon: <Award className="h-6 w-6 text-gold-500" />,
      color: 'gold'
    },
    {
      label: 'Average Clean Rating',
      value: `${rating} ★`,
      sub: 'Out of 5 Stars',
      icon: <Star className="h-6 w-6 text-gold-500 fill-gold-500" />,
      color: 'gold'
    },
    {
      label: 'Happy Clients',
      value: `${clients}+`,
      sub: 'Precision Styling',
      icon: <Users className="h-6 w-6 text-gold-500" />,
      color: 'gold'
    },
    {
      label: 'Professional Experience',
      value: `${years}+ Years`,
      sub: 'Serving Delhi NCR',
      icon: <Briefcase className="h-6 w-6 text-gold-500" />,
      color: 'gold'
    },
  ];

  return (
    <section id="stats" className="relative py-12 bg-white/[0.02] border-y border-white/5 overflow-hidden">
      <div className="absolute inset-0 bg-radial-[circle_at_bottom_rgba(212,175,55,0.03)_0%,transparent_50%] pointer-events-none" />
      
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-y-8 gap-x-4 md:grid-cols-4 md:gap-x-8">
          {statsItems.map((item, index) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center p-5 rounded-2xl glass-effect flex flex-col items-center justify-center border border-white/[0.03] transition-all hover:border-gold-500/20 group hover:shadow-[0_12px_24px_rgba(0,0,0,0.4)]"
            >
              {/* Animated Icon Ring */}
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-white/5 border border-white/10 group-hover:border-gold-500/30 group-hover:bg-gold-500/10 transition-colors duration-300">
                {item.icon}
              </div>

              {/* Number Value */}
              <h3 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-white mb-1 group-hover:scale-105 transition-transform duration-300">
                {item.value}
              </h3>

              {/* Label */}
              <span className="text-gray-300 font-sans font-medium text-xs sm:text-sm uppercase tracking-wider block">
                {item.label}
              </span>

              {/* Secondary Detail */}
              <span className="text-gold-500/80 font-sans text-[10px] sm:text-xs mt-1 block">
                {item.sub}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
