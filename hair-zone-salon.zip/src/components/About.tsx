import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, HeartOff, Sparkles, Check, Gem } from 'lucide-react';

interface AboutProps {
  onOpenBooking: () => void;
}

export default function About({ onOpenBooking }: AboutProps) {
  // Luxury salon setting representing Hair Zone Delhi
  const ABOUT_IMG = "https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=800&q=80";

  return (
    <section id="about" className="relative py-20 sm:py-28 overflow-hidden bg-brand-dark font-sans">
      {/* Decorative Gold Elements */}
      <div className="absolute top-1/4 -right-64 h-96 w-96 rounded-full bg-gold-500/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 -left-64 h-96 w-96 rounded-full bg-gold-400/5 blur-[120px] pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Aesthetic Left Side Image Card */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="lg:col-span-5 relative"
          >
            {/* Background frame decoration */}
            <div className="absolute -inset-3 rounded-2xl border border-gold-500/20 translate-x-4 translate-y-4 pointer-events-none rounded-2xl" />

            <div className="relative overflow-hidden rounded-2xl border border-white/10 shadow-2xl group">
              <img
                src={ABOUT_IMG}
                alt="Hair Zone Salon Professional Stylist"
                referrerPolicy="no-referrer"
                className="w-full object-cover aspect-[4/5] object-center transition-transform duration-700 group-hover:scale-105"
              />
              {/* Image Gradient Dark Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              
              {/* Float Experience badge */}
              <div className="absolute bottom-5 left-5 right-5 rounded-xl glass-effect border border-gold-500/20 p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold-500 text-black">
                    <Gem className="h-5 w-5" />
                  </div>
                  <div>
                    <h5 className="font-serif text-sm font-bold tracking-wide text-white">#1 Rated in Delhi NCR</h5>
                    <p className="text-gray-400 text-xs mt-0.5">Over 1,000+ satisfied clients and counting</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Elegant Content Right Side */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="lg:col-span-7 space-y-6"
          >
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="h-px w-8 bg-gold-500" />
                <span className="font-sans text-xs font-bold uppercase tracking-widest text-gold-500">EXQUISITE GROOMING</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white">
                About <span className="text-gold-gradient italic">Hair Zone Salon</span>
              </h2>
            </div>

            <p className="text-gray-300 text-base leading-relaxed font-light">
              Hair Zone Salon is a premium grooming destination located in Rajouri Garden, Delhi. We specialize in stylish haircuts, professional grooming, hair treatments, beard styling, and complete makeover services. Our experienced team focuses on quality, hygiene, and customer satisfaction to deliver an exceptional salon experience.
            </p>

            <p className="text-gray-400 text-sm leading-relaxed">
              Designed as a modern sanctuary of personal styling, we blend classical barbering standards with avant-garde styling techniques. Each treatment utilizes state-of-the-art hair diagnostics and gold-tier products to protect and rejuvenate your natural hair and skin.
            </p>

            {/* Structured Value Points */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 pb-6">
              {[
                { title: 'Certified Hair Doctors', desc: 'Expert stylists with 5+ years of specialized experience.' },
                { title: 'Strict Clinical Hygiene', desc: 'Surgical level sanitation of all tools and chairs.' },
                { title: 'Organic Premium Products', desc: 'Luxury brands that nurture your hair, roots and skin.' },
                { title: 'Personalized Artistry', desc: 'Consultations to match your unique face structure.' }
              ].map((val) => (
                <div key={val.title} className="flex gap-3">
                  <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gold-500/10 text-gold-500 border border-gold-500/30 font-bold mt-1">
                    <Check className="h-3 w-3 stroke-[3]" />
                  </div>
                  <div>
                    <h4 className="font-sans font-semibold text-sm text-white tracking-wide">{val.title}</h4>
                    <p className="text-gray-400 text-xs mt-0.5">{val.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA action */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button
                id="about-book-btn"
                onClick={onOpenBooking}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gold-500 px-7 py-3.5 font-serif text-xs font-bold uppercase tracking-wider text-black hover:bg-gold-600 transition-all cursor-pointer shadow-lg active:scale-[0.98] bg-gold-gradient"
              >
                Experience Now
              </button>
              
              <div className="flex items-center justify-center sm:justify-start gap-4 px-2">
                <div className="text-left">
                  <span className="text-[10px] text-gray-500 block uppercase tracking-wider font-semibold">DIRECT ROUTE</span>
                  <span className="text-sm text-gold-400 font-medium font-sans">Opposite DCB Bank, Delhi</span>
                </div>
              </div>
            </div>

          </motion.div>

        </div>
      </div>
    </section>
  );
}
