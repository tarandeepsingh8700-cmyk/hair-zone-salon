import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, PhoneCall, CalendarPlus } from 'lucide-react';

interface HeroProps {
  onOpenBooking: () => void;
}

export default function Hero({ onOpenBooking }: HeroProps) {
  // Luxury styling hero background of high-end salon
  const HERO_BG = "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1920&q=90";

  return (
    <section
      id="home"
      className="relative flex h-screen min-h-[650px] w-full items-center justify-center overflow-hidden bg-brand-dark"
    >
      {/* Img background with subtle motion */}
      <motion.div
        initial={{ scale: 1.1, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.4 }}
        transition={{ duration: 1.8, ease: 'easeOut' }}
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${HERO_BG})` }}
      />

      {/* Luxury Golden Ambient Glow */}
      <div className="absolute inset-0 bg-radial-[circle_at_center_rgba(212,175,55,0.08)_0%,transparent_60%] pointer-events-none" />

      {/* Dark vignette overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-brand-dark/70 to-brand-dark/40" />

      {/* Content wrapper */}
      <div className="relative z-10 mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8 mt-16 sm:mt-12">
        {/* Animated Little Header Tag */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-gold-400"
        >
          <Sparkles className="h-3.5 w-3.5 animate-pulse text-gold-500" />
          <span>The Grooming Masterpiece in Delhi</span>
        </motion.div>

        {/* Brand Major Title */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-semibold tracking-tight text-white mb-6 leading-[1.12]"
        >
          Transform Your Look <br />
          With <span className="text-gold-gradient italic font-serif">Style & Confidence</span>
        </motion.h1>

        {/* Brand Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mx-auto max-w-2xl text-gray-300 font-sans text-base sm:text-lg md:text-xl leading-relaxed mb-10 font-light"
        >
          Experience luxury grooming, modern styling, and exceptional salon services at{' '}
          <strong className="text-gold-400 font-medium tracking-wide">Hair Zone Salon</strong> Rajouri Garden. Let our award-winning artists craft your signature look.
        </motion.p>

        {/* Buttons Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-5"
        >
          <button
            id="hero-booking-btn"
            onClick={onOpenBooking}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 rounded-xl bg-gold-500 px-8 py-4 font-serif text-sm font-bold uppercase tracking-wider text-black hover:bg-gold-600 transition-all shadow-xl shadow-gold-500/15 cursor-pointer hover:shadow-gold-500/30 active:scale-[0.98] bg-gold-gradient"
          >
            <CalendarPlus className="h-4 w-4 stroke-[2.5]" />
            Book Appointment
          </button>

          <a
            id="hero-call-btn"
            href="tel:09654336671"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 rounded-xl border border-white/10 bg-white/5 px-8 py-4 font-serif text-sm font-bold uppercase tracking-wider text-white hover:bg-white/10 hover:border-white/20 transition-all cursor-pointer backdrop-blur"
          >
            <PhoneCall className="h-4 w-4 text-gold-500" />
            <span>Call: 09654336671</span>
          </a>
        </motion.div>
      </div>

      {/* Decorative luxury gradient bottom divider */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-brand-dark to-transparent pointer-events-none" />
    </section>
  );
}
