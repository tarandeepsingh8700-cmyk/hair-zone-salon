import React from 'react';
import { motion } from 'motion/react';
import { PhoneCall, CalendarCheck2, Sparkles } from 'lucide-react';

interface CTAProps {
  onOpenBooking: () => void;
}

export default function CTA({ onOpenBooking }: CTAProps) {
  return (
    <section id="cta" className="relative py-20 sm:py-24 bg-brand-dark/95 overflow-hidden font-sans border-t border-white/5">
      {/* Golden spotlight radial background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center_rgba(212,175,55,0.06)_0%,transparent_60%)] pointer-events-none" />
      <div className="absolute top-1/2 left-0 h-px w-full bg-gradient-to-r from-transparent via-gold-500/10 to-transparent" />

      <div className="relative z-10 mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        
        {/* Pulse Indicator Ring */}
        <div className="flex justify-center mb-6">
          <div className="relative">
            <div className="absolute -inset-1 animate-ping rounded-full bg-gold-500/20 opacity-75" />
            <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-gold-400 text-black shadow-lg shadow-gold-500/20">
              <Sparkles className="h-6 w-6 stroke-[2]" />
            </div>
          </div>
        </div>

        {/* Heading */}
        <h2 className="font-serif text-3.5xl sm:text-4.5xl md:text-5xl font-bold tracking-tight text-white mb-4">
          Ready For A <span className="text-gold-gradient italic">Fresh New Look?</span>
        </h2>
        
        {/* Caption */}
        <p className="mx-auto max-w-xl text-gray-300 text-sm sm:text-base mb-8 font-light leading-relaxed">
          Unlock your individual styling blueprint today. Secure your signature haircut, hair spa, or groom therapy with Delhi's award-winning hair artisans.
        </p>

        {/* Pulsating buttons container */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
          <button
            id="cta-book-btn"
            onClick={onOpenBooking}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 rounded-xl bg-gold-500 px-8 py-4 font-serif text-sm font-bold uppercase tracking-wider text-black hover:bg-gold-600 transition-all cursor-pointer shadow-lg active:scale-[0.98] bg-gold-gradient shrink-0"
          >
            <CalendarCheck2 className="h-4 w-4" />
            Book Appointment
          </button>

          <a
            id="cta-call-btn"
            href="tel:09654336671"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-8 py-4 font-serif text-sm font-bold uppercase tracking-wider text-white transition-all cursor-pointer shrink-0"
          >
            <PhoneCall className="h-4 w-4 text-gold-500" />
            Call: 09654336671
          </a>
        </div>

      </div>
    </section>
  );
}
