import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight, Eye, Grid3X3, Sparkles } from 'lucide-react';
import { GalleryItem } from '../types';

const GALLERY_DATA: GalleryItem[] = [
  {
    id: '1',
    title: 'High-Fashion Blonde Color Balayage',
    image: 'https://images.unsplash.com/photo-1605497746444-05db06c39f21?auto=format&fit=crop&w=800&q=80',
    category: 'coloring'
  },
  {
    id: '2',
    title: 'Sharp Fade & Royal Beard Trim',
    image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=800&q=80',
    category: 'haircuts'
  },
  {
    id: '3',
    title: 'Luxury Bridal Makeup Portfolio',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=800&q=80',
    category: 'makeup'
  },
  {
    id: '4',
    title: 'Sleek Mirror Glass Keratin Treatment',
    image: 'https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=800&q=80',
    category: 'styling'
  },
  {
    id: '5',
    title: 'Gold Hydra-Facial Aesthetics',
    image: 'https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?auto=format&fit=crop&w=800&q=80',
    category: 'makeup'
  },
  {
    id: '6',
    title: 'Precision Layered Scissors Cut',
    image: 'https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=800&q=80',
    category: 'haircuts'
  }
];

export default function Gallery() {
  const [activeFilter, setActiveFilter] = useState<'all' | 'haircuts' | 'coloring' | 'makeup' | 'styling'>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  
  // Interactive Before/After slider position (0-100)
  const [sliderPos, setSliderPos] = useState(50);

  const filteredItems = GALLERY_DATA.filter((item) =>
    activeFilter === 'all' ? true : item.category === activeFilter
  );

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((prevIndex) => (prevIndex === 0 ? filteredItems.length - 1 : prevIndex! - 1));
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((prevIndex) => (prevIndex === filteredItems.length - 1 ? 0 : prevIndex! + 1));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft') handlePrev(e as any);
    if (e.key === 'ArrowRight') handleNext(e as any);
    if (e.key === 'Escape') setLightboxIndex(null);
  };

  return (
    <section id="gallery" className="relative py-20 sm:py-28 bg-brand-dark overflow-hidden font-sans">
      {/* Glow elements */}
      <div className="absolute top-0 right-0 h-96 w-96 rounded-full bg-gold-500/[0.01] blur-[130px] pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Gallery Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="flex items-center justify-center gap-2">
            <span className="h-px w-6 bg-gold-500" />
            <span className="text-xs font-bold uppercase tracking-widest text-gold-400">SALON TRANSFORMATIONS</span>
            <span className="h-px w-6 bg-gold-500" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-2">
            Artistry <span className="text-gold-gradient italic">In Action</span>
          </h2>
          <p className="text-gray-400 text-sm font-light leading-relaxed">
            Witness real transformations at Hair Zone Salon. Drag our slider below to reveal before/after results, or click images to inspect detailed portfolio work.
          </p>
        </div>

        {/* 1. BEFORE AFTER INTERACTIVE CONTAINER */}
        <div className="mx-auto max-w-2xl mb-20">
          <h3 className="font-serif text-xl sm:text-2xl font-bold text-center text-white mb-6 flex items-center justify-center gap-2">
            <Sparkles className="h-5 w-5 text-gold-500" />
            Interactive Hair Transformation
          </h3>
          
          <div id="before-after-slider-container" className="relative aspect-[16/10] w-full select-none overflow-hidden rounded-2xl border border-white/10 shadow-2xl bg-brand-gray">
            {/* After (Bottom) Image */}
            <img
              src="https://images.unsplash.com/photo-1596415668744-8df60237f8f9?auto=format&fit=crop&w=1000&q=80"
              alt="After styled Hair Zone haircut look"
              referrerPolicy="no-referrer"
              className="absolute inset-0 h-full w-full object-cover object-center pointer-events-none"
            />
            <div className="absolute right-4 bottom-4 z-10 rounded-lg bg-gold-500/95 text-black text-[10px] font-bold uppercase tracking-wider px-3 py-1 bg-gold-gradient">
              After (styled)
            </div>

            {/* Before (Top) Image Clipped */}
            <div
              className="absolute inset-0 h-full w-full overflow-hidden"
              style={{ clipPath: `polygon(0 0, ${sliderPos}% 0, ${sliderPos}% 100%, 0 100%)` }}
            >
              <img
                src="https://images.unsplash.com/photo-1582095133179-bfd08e2fc6b3?auto=format&fit=crop&w=1000&q=80"
                alt="Before unstyled Hair Zone haircut look"
                referrerPolicy="no-referrer"
                className="absolute inset-0 h-full w-full object-cover object-center pointer-events-none"
              />
              <div className="absolute left-4 bottom-4 z-10 rounded-lg bg-black/80 border border-white/10 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1">
                Before (unstyled)
              </div>
            </div>

            {/* Scribing bar handle */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-gold-500 z-20 pointer-events-none cursor-ew-resize flex items-center justify-center"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="h-10 w-10 rounded-full bg-gold-500 border-4 border-black font-extrabold flex items-center justify-center text-black text-xs shadow-xl shrink-0 -ml-5">
                ↔
              </div>
            </div>

            {/* Transparent HTML5 range slider laid on top of container to listen to slides */}
            <input
              id="before-after-range-input"
              type="range"
              min="0"
              max="100"
              value={sliderPos}
              onChange={(e) => setSliderPos(Number(e.target.value))}
              aria-label="Before after styling visual scrubber slider"
              className="absolute inset-0 z-30 h-full w-full cursor-ew-resize opacity-0 accent-gold-500"
            />
          </div>
          <p className="text-center text-xs text-gray-500 mt-3 italic">
            Slide horizontal handle above back & forth to scrub between before and after.
          </p>
        </div>

        {/* 2. MASONRY PORTFOLIO GALLERY */}
        <div className="space-y-10">
          
          {/* Gallery Category Navigation */}
          <div className="flex flex-wrap justify-center gap-1.5 sm:gap-2.5 max-w-2xl mx-auto">
            {[
              { id: 'all', label: 'All Work' },
              { id: 'haircuts', label: 'Haircuts' },
              { id: 'coloring', label: 'Coloring' },
              { id: 'makeup', label: 'Makeup & Facial' },
              { id: 'styling', label: 'Treatments' }
            ].map((f) => (
              <button
                key={f.id}
                id={`gallery-filter-${f.id}`}
                onClick={() => setActiveFilter(f.id as any)}
                className={`rounded-xl px-4 py-2 text-xs sm:text-sm font-medium tracking-wide transition-all cursor-pointer ${
                  activeFilter === f.id
                    ? 'border border-gold-500 text-gold-500 bg-gold-500/5 font-semibold'
                    : 'border border-white/5 text-gray-400 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Mosaic Grid */}
          <motion.div
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
          >
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item, index) => (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  key={item.id}
                  id={`gallery-item-${item.id}`}
                  onClick={() => setLightboxIndex(index)}
                  className="group relative cursor-pointer overflow-hidden rounded-2xl border border-white/5 bg-brand-gray aspect-[4/3]"
                >
                  {/* Photo element */}
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-110"
                  />
                  
                  {/* Zoom overlay glass mask */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6 border border-gold-500/20 rounded-2xl" />

                  {/* Zoom symbol top right */}
                  <div className="absolute top-4 right-4 h-10 w-10 bg-black/60 border border-white/10 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                    <Eye className="h-4.5 w-4.5 text-gold-500" />
                  </div>

                  {/* Information label content */}
                  <div className="absolute bottom-0 left-0 right-0 p-5 transform translate-y-3 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300 z-10 text-left">
                    <span className="text-[10px] font-bold text-gold-500 uppercase tracking-widest block mb-1">
                      {item.category.toUpperCase()}
                    </span>
                    <h4 className="font-serif text-base sm:text-lg font-bold text-white tracking-wide">
                      {item.title}
                    </h4>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>

      </div>

      {/* 3. LIGHTBOX POPUP MODAL */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <div
            id="gallery-lightbox"
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4"
            onKeyDown={handleKeyDown}
            tabIndex={0}
            onClick={() => setLightboxIndex(null)}
          >
            {/* Header / close panel */}
            <div className="absolute top-6 left-6 right-6 flex items-center justify-between text-white z-10">
              <span className="font-sans text-xs sm:text-sm tracking-widest uppercase font-medium text-gray-400">
                TRANSFORMATION {lightboxIndex + 1} OF {filteredItems.length}
              </span>
              <button
                id="close-lightbox-btn"
                onClick={() => setLightboxIndex(null)}
                className="rounded-full bg-white/5 border border-white/10 p-2 text-white hover:bg-white/15 hover:text-gold-500 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Left Button */}
            <button
              id="prev-lightbox-btn"
              onClick={handlePrev}
              className="absolute left-4 sm:left-8 z-10 h-11 w-11 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/10 hover:text-gold-500 flex items-center justify-center transition-colors cursor-pointer"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>

            {/* Large Main Image Display */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-4xl max-h-[80vh] overflow-hidden rounded-xl border border-white/10 text-center"
            >
              <img
                src={filteredItems[lightboxIndex].image}
                alt={filteredItems[lightboxIndex].title}
                referrerPolicy="no-referrer"
                className="w-full max-h-[75vh] object-contain mx-auto"
              />
              
              {/* Caption Tag overlay */}
              <div className="p-4 bg-brand-gray text-left border-t border-white/5">
                <span className="text-[10px] text-gold-500 font-bold uppercase tracking-widest block mb-0.5">
                  HAIR ZONE CREATION
                </span>
                <p className="text-xs sm:text-sm text-gray-300 font-serif font-semibold tracking-wide">
                  {filteredItems[lightboxIndex].title}
                </p>
              </div>
            </motion.div>

            {/* Right Button */}
            <button
              id="next-lightbox-btn"
              onClick={handleNext}
              className="absolute right-4 sm:right-8 z-10 h-11 w-11 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/10 hover:text-gold-500 flex items-center justify-center transition-colors cursor-pointer"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
