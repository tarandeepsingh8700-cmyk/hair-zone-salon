import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { Review } from '../types';

const REVIEWS_DATA: Review[] = [
  {
    id: '1',
    name: 'Tarun Singh',
    role: 'Local Guide, Rajouri Garden',
    rating: 5,
    text: 'Excellent service and professional staff. Highly recommended. I got my haircut and hair spa done here. The senior stylist was very professional and suggested exactly what fits my forehead style.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: '2',
    name: 'Anjali Sharma',
    role: 'Verified Customer',
    rating: 5,
    text: 'Best salon experience in Rajouri Garden. Extremely hygienic; they sanitized all grooming equipment and chairs right before my hair treatment began. The keratin service made my hair incredibly smooth!',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: '3',
    name: 'Rajen Malhotra',
    role: 'Regular Patron',
    rating: 5,
    text: 'Great haircut and grooming services. The beard grooming with hot towels and premium essential oils was so relaxing. Excellent luxurious vibe with high quality coffee.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80'
  }
];

export default function Reviews() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev === REVIEWS_DATA.length - 1 ? 0 : prev + 1));
    }, 4500); // cycle testimonials every 4.5s
    return () => clearInterval(timer);
  }, []);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? REVIEWS_DATA.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === REVIEWS_DATA.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="reviews" className="relative py-20 sm:py-28 bg-brand-gray overflow-hidden font-sans">
      {/* Decorative quotes background watermark */}
      <div className="absolute top-10 left-10 text-white/[0.01] pointer-events-none select-none">
        <Quote className="h-96 w-96 font-extrabold rotate-180" />
      </div>

      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-xl mx-auto mb-16 space-y-3">
          <div className="flex items-center justify-center gap-2">
            <span className="h-px w-6 bg-gold-500" />
            <span className="text-xs font-bold uppercase tracking-widest text-gold-400">PATRON VERDICTS</span>
            <span className="h-px w-6 bg-gold-500" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-2">
            Loved By <span className="text-gold-gradient italic">Our Clientele</span>
          </h2>
          <p className="text-gray-400 text-sm font-light">
            Read verified feedback from patrons with an impressive average rating of 4.8★ spanning 172+ local Google reviews.
          </p>
        </div>

        {/* Carousel Container */}
        <div className="relative mx-auto max-w-3xl">
          
          {/* Active Review View */}
          <div id="testimonial-carousel-viewport" className="relative overflow-hidden rounded-3xl glass-effect p-8 sm:p-12 border border-white/5 text-center min-h-[320px] flex flex-col justify-center items-center shadow-2xl">
            
            {/* Quote decorative top */}
            <div className="flex justify-center text-gold-500/20 mb-6">
              <Quote className="h-10 w-10 stroke-[1.5]" />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.4 }}
                className="space-y-6"
              >
                {/* 5 Golden Stars */}
                <div className="flex justify-center gap-1">
                  {[...Array(REVIEWS_DATA[currentIndex].rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-gold-500 text-gold-500 animate-pulse" />
                  ))}
                </div>

                {/* Testimonial Message */}
                <p className="font-serif text-lg sm:text-xl md:text-2xl text-white italic leading-relaxed max-w-2xl font-medium tracking-wide">
                  "{REVIEWS_DATA[currentIndex].text}"
                </p>

                {/* Author Info */}
                <div className="flex items-center justify-center gap-3 pt-4">
                  <img
                    src={REVIEWS_DATA[currentIndex].image}
                    alt={REVIEWS_DATA[currentIndex].name}
                    referrerPolicy="no-referrer"
                    className="h-12 w-12 rounded-full border-2 border-gold-500/30 object-cover"
                  />
                  <div className="text-left">
                    <h4 className="font-sans font-bold text-sm text-white tracking-wide">
                      {REVIEWS_DATA[currentIndex].name}
                    </h4>
                    <span className="text-xs text-gray-500 mt-0.5 block">
                      {REVIEWS_DATA[currentIndex].role}
                    </span>
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>

          </div>

          {/* Navigation controls */}
          <div className="flex justify-center items-center gap-5 mt-8">
            <button
              id="prev-review-btn"
              onClick={handlePrev}
              className="h-11 w-11 rounded-full border border-white/10 text-gray-400 hover:text-gold-500 hover:border-gold-500/30 flex items-center justify-center transition-all cursor-pointer bg-black/20"
              aria-label="Previous Testimonial"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            {/* Micro dots */}
            <div className="flex gap-2">
              {REVIEWS_DATA.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`h-2.5 rounded-full transition-all duration-350 cursor-pointer ${
                    currentIndex === i ? 'w-6 bg-gold-500' : 'w-2.5 bg-white/10'
                  }`}
                  aria-label={`Go to testimonial ${i + 1}`}
                />
              ))}
            </div>

            <button
              id="next-review-btn"
              onClick={handleNext}
              className="h-11 w-11 rounded-full border border-white/10 text-gray-400 hover:text-gold-500 hover:border-gold-500/30 flex items-center justify-center transition-all cursor-pointer bg-black/20"
              aria-label="Next Testimonial"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>

        </div>

      </div>
    </section>
  );
}
