import React from 'react';
import { motion } from 'motion/react';
import { Award, ShieldCheck, Gem, CircleDollarSign, Heart, Sparkles } from 'lucide-react';

interface FeaturePoint {
  title: string;
  desc: string;
  icon: React.ReactNode;
}

const FEATURE_POINTS: FeaturePoint[] = [
  {
    title: 'Professional Stylists',
    desc: 'Our artists undergo global masterclasses in Paris and Delhi to bring contemporary aesthetics to Rajouri Garden.',
    icon: <Award className="h-6 w-6 text-gold-500" />
  },
  {
    title: 'Premium Products',
    desc: 'We strictly employ luxury organic hair blends, clinical scalp protectants, and ammonia-free dyes.',
    icon: <Gem className="h-6 w-6 text-gold-500" />
  },
  {
    title: 'Hygienic Environment',
    desc: 'We follow continuous UV-sterilization for scissors, razors, and offer ultra-filtered fresh air stations.',
    icon: <ShieldCheck className="h-6 w-6 text-gold-500" />
  },
  {
    title: 'Affordable Pricing',
    desc: 'Premium high-end aesthetics made accessible. Transparent rates with zero surprise or hidden add-on costs.',
    icon: <CircleDollarSign className="h-6 w-6 text-gold-500" />
  },
  {
    title: 'Customer Satisfaction',
    desc: 'A spectacular 4.8★ rating with 172+ verified Google user reviews reflecting our care, attention and luxury coffee bar.',
    icon: <Heart className="h-6 w-6 text-gold-500" />
  },
  {
    title: 'Modern Techniques',
    desc: 'Utilizing state-of-the-art scalp analysis scanners, precision laser trimmer guides, and premium steam-infusions.',
    icon: <Sparkles className="h-6 w-6 text-gold-500" />
  }
];

export default function WhyChooseUs() {
  return (
    <section id="why-choose-us" className="relative py-20 sm:py-28 bg-brand-dark/95 font-sans overflow-hidden">
      {/* Golden accent blur */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-gold-500/[0.015] blur-[140px] pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Detail Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="flex items-center justify-center gap-2">
            <span className="h-px w-6 bg-gold-500" />
            <span className="text-xs font-bold uppercase tracking-widest text-gold-400">WHY COVET US</span>
            <span className="h-px w-6 bg-gold-500" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white animate-fade-in">
            A Higher Standard of <span className="text-gold-gradient italic">Craftsmanship</span>
          </h2>
          <p className="text-gray-400 text-sm font-light leading-relaxed">
            At Hair Zone Salon, we do not simply perform hair cuts; we craft visual identities with exceptional customer comfort, elite hygiene, and certified care.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {FEATURE_POINTS.map((pt, idx) => (
            <motion.div
              key={pt.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: idx * 0.08 }}
              className="group rounded-2xl glass-effect p-6 sm:p-8 border border-white/[0.04] hover:border-gold-500/20 hover:shadow-[0_12px_36px_rgba(0,0,0,0.5)] transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Custom Ring Around Icon */}
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/5 border border-white/10 group-hover:border-gold-500/30 group-hover:bg-gold-500/10 transition-all duration-300">
                  <div className="group-hover:scale-110 transition-transform duration-300">
                    {pt.icon}
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-serif text-lg sm:text-xl font-bold text-white tracking-wide group-hover:text-gold-400 transition-colors">
                    {pt.title}
                  </h3>
                  <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-light">
                    {pt.desc}
                  </p>
                </div>
              </div>

              {/* Gold bullet decoration bottom right */}
              <div className="mt-6 flex justify-end">
                <span className="h-1.5 w-8 rounded-full bg-white/[0.08] group-hover:bg-gold-500 transition-colors duration-300" />
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
