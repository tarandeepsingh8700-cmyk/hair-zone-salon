import React, { useState, useEffect } from 'react';
import { Menu, X, Scissors, PhoneCall, CalendarRange } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  onOpenBooking: (service?: string) => void;
}

export default function Navbar({ onOpenBooking }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offset = 80; // height of sticky header
      const elementPosition = targetElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <header
        id="main-header"
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'glass-effect py-3 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] border-b border-gold-500/10'
            : 'bg-transparent py-5'
        }`}
      >
        <div id="nav-container" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <a
              id="header-logo-link"
              href="#home"
              onClick={(e) => handleLinkClick(e, '#home')}
              className="flex items-center gap-2 group cursor-pointer focus:outline-none"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold-500 text-black shadow-lg transition-transform group-hover:scale-105 duration-300">
                <Scissors className="h-5 w-5 stroke-[2]" />
              </div>
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-wider text-white group-hover:text-gold-400 transition-colors">
                HAIR ZONE<span className="text-gold-500 ml-0.5">.</span>
              </span>
            </a>

            {/* Desktop Navigation Links */}
            <nav id="desktop-nav" className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  id={`nav-link-${link.name.toLowerCase()}`}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  className="font-sans text-sm font-medium tracking-wide text-gray-300 hover:text-gold-500 transition-all duration-200 relative group py-2"
                >
                  {link.name}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold-500 transition-all duration-300 group-hover:w-full" />
                </a>
              ))}
            </nav>

            {/* Contact Call & Action Button */}
            <div id="navbar-actions" className="hidden lg:flex items-center gap-6">
              <a
                id="navbar-phone-call-link"
                href="tel:09654336671"
                className="flex items-center gap-2 group text-sm font-semibold text-white/90 hover:text-gold-500 transition-colors"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 border border-white/10 group-hover:border-gold-500/20 group-hover:bg-gold-500/5 transition-colors">
                  <PhoneCall className="h-3.5 w-3.5 text-gold-500 group-hover:scale-110 transition-transform" />
                </div>
                <span>09654336671</span>
              </a>

              <button
                id="navbar-booking-btn"
                onClick={() => onOpenBooking()}
                className="inline-flex items-center gap-2 rounded-xl bg-gold-500 px-5 py-2.5 font-serif text-xs font-bold uppercase tracking-wider text-black hover:bg-gold-600 active:scale-[0.98] transition-all duration-200 cursor-pointer shadow-md shadow-gold-500/10 hover:shadow-gold-500/20"
              >
                <CalendarRange className="h-4 w-4" />
                Book Slot
              </button>
            </div>

            {/* Mobile hamburger menu button */}
            <div className="flex items-center md:hidden gap-3">
              <button
                id="mobile-call-btn"
                onClick={() => window.open('tel:09654336671')}
                className="p-2.5 rounded-xl bg-white/5 text-gold-500 hover:bg-white/10 transition-colors border border-white/5"
              >
                <PhoneCall className="h-4 w-4" />
              </button>

              <button
                id="mobile-nav-toggle"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="rounded-xl bg-gold-500/10 p-2.5 text-gold-500 hover:bg-gold-500/20 md:hidden transition-colors border border-gold-500/20 focus:outline-none"
                aria-label="Toggle Navigation Menu"
              >
                {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              id="mobile-nav-menu"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="md:hidden glass-effect border-b border-gold-500/15 overflow-hidden"
            >
              <div className="space-y-1.5 px-4 pt-2 pb-6 flex flex-col font-sans">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    id={`mobile-link-${link.name.toLowerCase()}`}
                    href={link.href}
                    onClick={(e) => handleLinkClick(e, link.href)}
                    className="block rounded-lg px-4 py-3 text-base font-medium text-gray-300 hover:bg-gold-500/10 hover:text-gold-500 transition-all border-l-2 border-transparent hover:border-gold-500"
                  >
                    {link.name}
                  </a>
                ))}
                
                <div className="p-3 border-t border-white/5 pt-5 mt-3 space-y-4">
                  <a
                    id="mobile-call-link-footer"
                    href="tel:09654336671"
                    className="flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-3 font-semibold text-white/90"
                  >
                    <PhoneCall className="h-4 w-4 text-gold-500" />
                    Call: 09654336671
                  </a>

                  <button
                    id="mobile-booking-drawer-btn"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onOpenBooking();
                    }}
                    className="w-full justify-center flex items-center gap-2 rounded-xl bg-gold-500 py-3.5 font-serif text-sm font-bold uppercase tracking-wider text-black hover:bg-gold-600 transition-colors"
                  >
                    <CalendarRange className="h-4 w-4" />
                    Book Appointment
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}
