import React from 'react';
import { Scissors, Instagram, Facebook, Phone, MapPin, Mail, Sparkles, ChevronRight } from 'lucide-react';

interface FooterProps {
  onOpenBooking: () => void;
}

export default function Footer({ onOpenBooking }: FooterProps) {
  const currentYear = 2026;

  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' }
  ];

  const coreServices = [
    'Hair Cutting',
    'Hair Styling',
    'Beard Grooming',
    'Hair Coloring',
    'Hair Spa',
    'Facial & Skin Care',
    'Keratin Treatment'
  ];

  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offset = 80;
      const elementPosition = targetElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer id="main-footer" className="relative bg-brand-dark border-t border-white/5 pt-16 pb-8 font-sans overflow-hidden">
      <div className="absolute inset-0 bg-radial-[circle_at_bottom_rgba(212,175,55,0.02)_0%,transparent_50%] pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Footer Grid columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-12 border-b border-white/5">
          
          {/* Col 1: Brand details */}
          <div className="lg:col-span-4 space-y-5">
            <a href="#home" onClick={(e) => handleSmoothScroll(e, '#home')} className="flex items-center gap-2 group focus:outline-none">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gold-500 text-black shadow">
                <Scissors className="h-4.5 w-4.5 stroke-[2]" />
              </div>
              <span className="font-serif text-lg font-bold tracking-wider text-white">
                HAIR ZONE<span className="text-gold-500">.</span>
              </span>
            </a>

            <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-light">
              Experience gold-tier barbering, high fashion styling, skin hydration therapies and wedding makeup inside our luxurious design lounges in Delhi.
            </p>

            {/* Social Icons */}
            <div className="flex gap-3">
              <a
                id="footer-insta-link"
                href="https://instagram.com/hairzonesalon"
                target="_blank"
                rel="noreferrer"
                className="h-8 w-8 rounded-lg bg-white/5 border border-white/10 text-gray-400 hover:text-gold-500 hover:border-gold-500/20 flex items-center justify-center transition-colors"
                aria-label="Hair Zone Instagram profile link"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                id="footer-fb-link"
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="h-8 w-8 rounded-lg bg-white/5 border border-white/10 text-gray-400 hover:text-gold-500 hover:border-gold-500/20 flex items-center justify-center transition-colors"
                aria-label="Hair Zone Facebook profile link"
              >
                <Facebook className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gold-500">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    onClick={(e) => handleSmoothScroll(e, link.href)}
                    className="text-gray-400 hover:text-gold-400 transition-colors flex items-center gap-1 group py-0.5"
                  >
                    <ChevronRight className="h-3 w-3 text-gold-500/0 group-hover:text-gold-500 transition-all transform group-hover:translate-x-0.5" />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Services mapping */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gold-500">
              Salon Services
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-gray-400 font-light">
              {coreServices.map((svc) => (
                <li key={svc} className="flex items-center gap-2">
                  <span className="h-1 w-1 rounded-full bg-gold-500/60" />
                  <span>{svc}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Contact links */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gold-500">
              Locate & Call
            </h4>
            <ul className="space-y-3.5 text-xs sm:text-sm text-gray-400 font-light">
              <li className="flex gap-2.5 items-start">
                <MapPin className="h-4 w-4 text-gold-500 shrink-0 mt-0.5" />
                <span>Ground Floor, F-159, Rajouri Garden, Block F, Delhi, 110027</span>
              </li>
              <li className="flex gap-2.5 items-center">
                <Phone className="h-4 w-4 text-gold-500 shrink-0" />
                <a href="tel:09654336671" className="text-white hover:text-gold-500 transition-colors font-medium">
                  09654336671
                </a>
              </li>
              <li className="flex gap-2.5 items-center">
                <Mail className="h-4 w-4 text-gold-500 shrink-0" />
                <span>info@hairzonesalon.com</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Footer Bottom copyright area */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-center">
          <p className="text-gray-500 text-xs text-left">
            © {currentYear} Hair Zone Salon. All Rights Reserved. Designed for premium styling.
          </p>
          <div className="flex gap-4 text-[10px] text-gray-500">
            <a href="#home" className="hover:text-gold-500 transition-colors">Safety Code</a>
            <span className="text-gray-700">|</span>
            <a href="#home" className="hover:text-gold-500 transition-colors">Hygiene Policy</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
