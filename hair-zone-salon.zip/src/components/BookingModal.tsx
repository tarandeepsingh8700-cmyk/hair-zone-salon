import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, Clock, Sparkles, Check, PhoneCall, AlertTriangle } from 'lucide-react';
import { BookingFormInput } from '../types';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedService?: string;
}

const SERVICES_LIST = [
  'Hair Cutting',
  'Hair Styling',
  'Beard Grooming',
  'Hair Coloring',
  'Hair Spa',
  'Facial & Skin Care',
  'Keratin Treatment',
  'Bridal & Party Makeup'
];

export default function BookingModal({ isOpen, onClose, preselectedService }: BookingModalProps) {
  const [formData, setFormData] = useState<BookingFormInput>({
    name: '',
    phone: '',
    service: '',
    date: '',
    time: '',
    message: ''
  });

  const [errors, setErrors] = useState<Partial<BookingFormInput>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [bookingId, setBookingId] = useState('');

  // Lock scroll when open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setFormData(prev => ({
        ...prev,
        service: preselectedService || ''
      }));
      setErrors({});
      setIsSuccess(false);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, preselectedService]);

  const validate = () => {
    const tempErrors: Partial<BookingFormInput> = {};
    if (!formData.name.trim()) tempErrors.name = 'Full name is required';
    if (!formData.phone.trim()) {
      tempErrors.phone = 'Phone number is required';
    } else if (!/^\d{10,11}$/.test(formData.phone.replace(/[\s\+\-]/g, ''))) {
      tempErrors.phone = 'Please enter a valid 10-digit phone number';
    }
    if (!formData.service) tempErrors.service = 'Please select a service';
    if (!formData.date) tempErrors.date = 'Appointment date is required';
    if (!formData.time) tempErrors.time = 'Appointment time is required';

    // Verify date is not in the past
    if (formData.date) {
      const selected = new Date(formData.date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (selected < today) {
        tempErrors.date = 'Appointment cannot be set in the past';
      }
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setBookingId('HZ-' + Math.floor(100000 + Math.random() * 900000));
    }, 1200);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="booking-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg overflow-hidden rounded-2xl glass-effect border border-gold-500/30 text-white shadow-2xl z-10"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 p-5">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-gold-500 animate-pulse" />
                <h3 className="font-serif text-xl font-semibold tracking-wide text-white">
                  {isSuccess ? 'Booking Confirmed' : 'Reserve Luxury Experience'}
                </h3>
              </div>
              <button
                id="close-booking-modal-btn"
                onClick={onClose}
                className="rounded-full p-1.5 text-gray-400 hover:bg-white/10 hover:text-white transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Success View */}
            {isSuccess ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-6 text-center"
              >
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gold-500/20 text-gold-500 border border-gold-500/40">
                  <Check className="h-8 w-8 stroke-[3]" />
                </div>
                <h4 className="font-serif text-2xl font-bold tracking-wide text-white mb-2">
                  See You Soon, {formData.name}!
                </h4>
                <p className="text-gray-400 text-sm mb-6 max-w-sm mx-auto">
                  Your premium reservation at Hair Zone Salon in Rajouri Garden has been booked successfully.
                </p>

                {/* Booking Receipt Card */}
                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-5 text-left space-y-3 mb-6 font-sans">
                  <div className="flex justify-between items-center text-xs pb-2 border-b border-white/5 text-gray-400">
                    <span>APPOINTMENT SECURED</span>
                    <span className="font-mono text-gold-400 font-semibold">{bookingId}</span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm mt-2">
                    <div>
                      <span className="text-xs text-gray-500 block">SERVICE</span>
                      <span className="font-medium text-white">{formData.service}</span>
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 block">STYLIST</span>
                      <span className="font-medium text-gold-400">Senior Stylist Assigned</span>
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 block">DATE</span>
                      <span className="font-medium text-white flex items-center gap-1.5 mt-0.5">
                        <Calendar className="h-3.5 w-3.5 text-gold-500" />
                        {new Date(formData.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 block">TIME SLOT</span>
                      <span className="font-medium text-white flex items-center gap-1.5 mt-0.5">
                        <Clock className="h-3.5 w-3.5 text-gold-500" />
                        {formData.time}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-gold-500/10 border border-gold-500/20 text-gold-300 rounded-lg p-3 text-xs flex items-start gap-2.5 text-left mb-6">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-gold-500 mt-0.5" />
                  <p>
                    Please arrive 10 minutes prior to your slot. Contact us at <strong className="text-white font-semibold">09654336671</strong> directly if you need to reschedule or cancel.
                  </p>
                </div>

                <div className="flex gap-3">
                  <a
                    id="success-call-btn"
                    href="tel:09654336671"
                    className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-3 font-semibold text-white hover:bg-white/10 transition-colors"
                  >
                    <PhoneCall className="h-4 w-4 text-gold-500" />
                    Call Salon
                  </a>
                  <button
                    id="success-dismiss-btn"
                    onClick={onClose}
                    className="flex-1 rounded-xl bg-gold-500 py-3 font-semibold text-black hover:bg-gold-600 transition-colors bg-gold-gradient shadow-md"
                  >
                    Done
                  </button>
                </div>
              </motion.div>
            ) : (
              /* Booking Input Form */
              <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                <p className="text-gray-300 text-sm italic mb-4">
                  Please provide your details below. We will secure your premium styling time slot immediately.
                </p>

                {/* Name */}
                <div>
                  <label htmlFor="booking-name" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                    Your Name <span className="text-gold-500">*</span>
                  </label>
                  <input
                    id="booking-name"
                    type="text"
                    required
                    className={`w-full rounded-xl bg-white/5 border ${
                      errors.name ? 'border-red-500' : 'border-white/15'
                    } px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors`}
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChange={e => {
                      setFormData({ ...formData, name: e.target.value });
                      if (errors.name) setErrors({ ...errors, name: undefined });
                    }}
                  />
                  {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                </div>

                {/* Phone */}
                <div>
                  <label htmlFor="booking-phone" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                    Mobile Number <span className="text-gold-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-3.5 text-gray-500 text-sm font-medium">+91</span>
                    <input
                      id="booking-phone"
                      type="tel"
                      required
                      className={`w-full rounded-xl bg-white/5 border ${
                        errors.phone ? 'border-red-500' : 'border-white/15'
                      } pl-14 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors`}
                      placeholder="9876543210"
                      value={formData.phone}
                      onChange={e => {
                        setFormData({ ...formData, phone: e.target.value });
                        if (errors.phone) setErrors({ ...errors, phone: undefined });
                      }}
                    />
                  </div>
                  {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                </div>

                {/* Service Selection */}
                <div>
                  <label htmlFor="booking-service" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                    Select Salon Service <span className="text-gold-500">*</span>
                  </label>
                  <select
                    id="booking-service"
                    required
                    className={`w-full rounded-xl bg-brand-gray border ${
                      errors.service ? 'border-red-500' : 'border-white/15'
                    } px-4 py-3 text-white focus:outline-none focus:border-gold-500 transition-colors`}
                    value={formData.service}
                    onChange={e => {
                      setFormData({ ...formData, service: e.target.value });
                      if (errors.service) setErrors({ ...errors, service: undefined });
                    }}
                  >
                    <option value="" disabled>Choose service...</option>
                    {SERVICES_LIST.map(svc => (
                      <option key={svc} value={svc}>{svc}</option>
                    ))}
                  </select>
                  {errors.service && <p className="text-red-500 text-xs mt-1">{errors.service}</p>}
                </div>

                {/* Date and Time (Side-by-side) */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="booking-date" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                      Date <span className="text-gold-500">*</span>
                    </label>
                    <input
                      id="booking-date"
                      type="date"
                      required
                      min={new Date().toISOString().split('T')[0]}
                      className={`w-full rounded-xl bg-white/5 border ${
                        errors.date ? 'border-red-500' : 'border-white/15'
                      } px-4 py-2.5 text-white focus:outline-none focus:border-gold-500 transition-colors [color-scheme:dark]`}
                      value={formData.date}
                      onChange={e => {
                        setFormData({ ...formData, date: e.target.value });
                        if (errors.date) setErrors({ ...errors, date: undefined });
                      }}
                    />
                    {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date}</p>}
                  </div>

                  <div>
                    <label htmlFor="booking-time" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                      Hour Time Slot <span className="text-gold-500">*</span>
                    </label>
                    <select
                      id="booking-time"
                      required
                      className={`w-full rounded-xl bg-brand-gray border ${
                        errors.time ? 'border-red-500' : 'border-white/15'
                      } px-4 py-3 text-white focus:outline-none focus:border-gold-500 transition-colors`}
                      value={formData.time}
                      onChange={e => {
                        setFormData({ ...formData, time: e.target.value });
                        if (errors.time) setErrors({ ...errors, time: undefined });
                      }}
                    >
                      <option value="" disabled>Choose time...</option>
                      <option value="10:00 AM">10:00 AM</option>
                      <option value="11:00 AM">11:00 AM</option>
                      <option value="12:00 PM">12:00 PM</option>
                      <option value="01:00 PM">01:00 PM</option>
                      <option value="02:00 PM">02:00 PM</option>
                      <option value="03:00 PM">03:00 PM</option>
                      <option value="04:00 PM">04:00 PM</option>
                      <option value="05:00 PM">05:00 PM</option>
                      <option value="06:00 PM">06:00 PM</option>
                      <option value="07:00 PM">07:00 PM</option>
                      <option value="08:00 PM">08:00 PM</option>
                    </select>
                    {errors.time && <p className="text-red-500 text-xs mt-1">{errors.time}</p>}
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label htmlFor="booking-instructions" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                    Special Instructions / Requests (Optional)
                  </label>
                  <textarea
                    id="booking-instructions"
                    rows={2}
                    className="w-full rounded-xl bg-white/5 border border-white/15 px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors"
                    placeholder="e.g. skin allergies, preferred stylist name, etc..."
                    value={formData.message}
                    onChange={e => setFormData({ ...formData, message: e.target.value })}
                  />
                </div>

                {/* Submit button */}
                <button
                  id="confirm-booking-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gold-500 border border-gold-600 font-serif font-bold text-black uppercase tracking-wider py-4 rounded-xl hover:bg-gold-600 transition-all shadow-lg active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed bg-gold-gradient"
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-black border-t-transparent" />
                      Securing Booking...
                    </span>
                  ) : (
                    'Confirm Premium Reservation'
                  )}
                </button>
              </form>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
