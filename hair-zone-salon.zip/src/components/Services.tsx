import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Scissors, Wind, Layers, Palette, Droplet, Sparkles, Crown, Gem, Clock, CalendarRange } from 'lucide-react';
import { Service } from '../types';

interface ServicesProps {
  onOpenBooking: (serviceName?: string) => void;
}

const SERVICES_DATA: Service[] = [
  {
    id: '1',
    title: 'Hair Cutting',
    category: 'styling',
    price: '₹599 - ₹1,199',
    duration: '45 Mins',
    description: 'Precision scissor and clipper work tailored to your crown shape, including hair wash and dynamic styling.',
    image: 'https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '2',
    title: 'Hair Styling',
    category: 'styling',
    price: '₹499 - ₹999',
    duration: '30 Mins',
    description: 'Luxury blowouts, curls, sleek ironing, or sophisticated up-dos for upscale occasions and celebrations.',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '3',
    title: 'Beard Grooming',
    category: 'grooming',
    price: '₹299 - ₹599',
    duration: '30 Mins',
    description: 'Hot towel shave, perimeter trim, razor line finishing, and conditioning with premium argan oils.',
    image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '4',
    title: 'Hair Coloring',
    category: 'styling',
    price: '₹1,999 - ₹4,999',
    duration: '120 Mins',
    description: 'Global colors, beautiful Balayage, root touch-ups, and custom streak highlights using safe, ammonia-free formulas.',
    image: 'https://images.unsplash.com/photo-1605497746444-05db06c39f21?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '5',
    title: 'Hair Spa',
    category: 'treatments',
    price: '₹999 - ₹1,899',
    duration: '60 Mins',
    description: 'Deep intensive conditioning, soothing scalp massage, active steam therapies to rescue dry, damaged cuticles.',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '6',
    title: 'Facial & Skin Care',
    category: 'treatments',
    price: '₹1,499 - ₹2,999',
    duration: '75 Mins',
    description: 'Gold-glint hydration facials, deep pore micro-cleans, organic peels, and skin tightening massages.',
    image: 'https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '7',
    title: 'Keratin Treatment',
    category: 'treatments',
    price: '₹2,999 - ₹5,999',
    duration: '180 Mins',
    description: 'Pro-keratin protein infusion to eliminate frizz, restore moisture, and leave hair sleek, glassy, and manageable.',
    image: 'https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '8',
    title: 'Bridal & Party Makeup',
    category: 'makeup',
    price: '₹4,999 - ₹14,999',
    duration: '150 Mins',
    description: 'Flawless HD/Airbrush makeup portfolios, eyelash styling, beauty contouring, and bridal draping.',
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80'
  }
];

const categoryIcons: Record<string, React.ReactNode> = {
  'Hair Cutting': <Scissors className="h-5 w-5 text-gold-500" />,
  'Hair Styling': <Wind className="h-5 w-5 text-gold-500" />,
  'Beard Grooming': <Layers className="h-5 w-5 text-gold-500" />,
  'Hair Coloring': <Palette className="h-5 w-5 text-gold-500" />,
  'Hair Spa': <Droplet className="h-5 w-5 text-gold-500" />,
  'Facial & Skin Care': <Sparkles className="h-5 w-5 text-gold-500" />,
  'Keratin Treatment': <Crown className="h-5 w-5 text-gold-500" />,
  'Bridal & Party Makeup': <Gem className="h-5 w-5 text-gold-500" />
};

export default function Services({ onOpenBooking }: ServicesProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'styling' | 'treatments' | 'makeup' | 'grooming'>('all');

  const tabs = [
    { id: 'all', label: 'All Services' },
    { id: 'styling', label: 'Styling & Cut' },
    { id: 'treatments', label: 'Spa & Care' },
    { id: 'grooming', label: 'Beard Grooming' },
    { id: 'makeup', label: 'Bridal & Party' }
  ];

  const filteredServices = SERVICES_DATA.filter(svc => 
    activeTab === 'all' ? true : svc.category === activeTab
  );

  return (
    <section id="services" className="relative py-20 sm:py-28 bg-brand-gray font-sans overflow-hidden">
      {/* Decorative background vectors */}
      <div className="absolute top-1/2 left-0 h-96 w-96 rounded-full bg-gold-500/[0.02] blur-[150px] pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="flex items-center justify-center gap-2">
            <span className="h-px w-6 bg-gold-500" />
            <span className="text-xs font-bold uppercase tracking-widest text-gold-400">OUR SERVICE LIST</span>
            <span className="h-px w-6 bg-gold-500" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white">
            Tailored <span className="text-gold-gradient italic">Styling Packages</span>
          </h2>
          <p className="text-gray-400 text-sm font-light leading-relaxed">
            Choose from list of curated grooming therapies, high fashion makeovers, and custom scalp repair procedures designed for premium elegance.
          </p>
        </div>

        {/* Tab Filters */}
        <div className="flex flex-wrap justify-center gap-1.5 sm:gap-2.5 mb-12 max-w-3xl mx-auto p-1 rounded-2xl bg-black/30 border border-white/5 backdrop-blur-sm">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              id={`service-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`rounded-xl px-4 sm:px-6 py-2.5 text-xs sm:text-sm font-medium tracking-wide transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-gold-500 text-black font-semibold bg-gold-gradient shadow'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredServices.map((service, index) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                key={service.id}
                id={`service-card-${service.id}`}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl bg-black/40 border border-white/5 transition-all duration-300 hover:border-gold-500/30 hover:shadow-[0_12px_40px_rgba(0,0,0,0.6)] hover:-translate-y-1.5"
              >
                {/* Card Top Image View */}
                <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-brand-dark border-b border-white/5">
                  <img
                    src={service.image}
                    alt={service.title}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-110"
                  />
                  {/* Subtle black overlay to make tags readable */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80" />
                  
                  {/* Category icon label */}
                  <div className="absolute top-4 left-4 flex h-10 w-10 items-center justify-center rounded-xl bg-black/60 border border-gold-500/20 backdrop-blur-md">
                    {categoryIcons[service.title] || <Scissors className="h-5 w-5 text-gold-500" />}
                  </div>

                  {/* Starting Price Badge */}
                  <div className="absolute bottom-3 right-4 rounded-lg bg-gold-500/90 hover:bg-gold-500 text-black font-semibold text-xs px-2.5 py-1 px-3 shadow">
                    {service.price.split(' ')[0]}
                  </div>
                </div>

                {/* Card Info Content */}
                <div className="flex-1 p-5 sm:p-6 space-y-4">
                  <div className="space-y-1.5">
                    <h3 className="font-serif text-lg sm:text-xl font-bold text-white tracking-wide group-hover:text-gold-400 transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-light line-clamp-3">
                      {service.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-white/[0.03]">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5 text-gold-500/80" />
                      {service.duration}
                    </span>
                    <span className="text-gold-500 text-[10px] font-bold uppercase tracking-wider">
                      Premium Class
                    </span>
                  </div>
                </div>

                {/* Book Action overlay bar */}
                <div className="p-5 sm:p-6 pt-0">
                  <button
                    id={`book-service-btn-${service.id}`}
                    onClick={() => onOpenBooking(service.title)}
                    className="w-full flex items-center justify-center gap-2 rounded-xl border border-gold-500/20 bg-gold-500/5 hover:bg-gold-500 font-serif text-xs font-bold uppercase tracking-wider text-gold-500 hover:text-black py-3.5 transition-all"
                  >
                    <CalendarRange className="h-3.5 w-3.5" />
                    Book Service
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Catalog Highlight note */}
        <div id="service-foot-note" className="mt-12 text-center">
          <p className="text-gray-500 text-xs">
            Prices may vary based on hair length, texture complexity, and customized treatments selected during your free consultation.
          </p>
        </div>

      </div>
    </section>
  );
}
