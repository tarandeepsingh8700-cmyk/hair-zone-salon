import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, MapPin, Clock, Instagram, Send, CheckCircle, AlertCircle, Sparkles, AlertTriangle } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    service: '',
    message: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const validate = () => {
    const tempErrors: Record<string, string> = {};
    if (!formData.name.trim()) tempErrors.name = 'Please provide your full name';
    if (!formData.phone.trim()) {
      tempErrors.phone = 'Mobile number is required';
    } else if (!/^\d{10}$/.test(formData.phone.replace(/[\s\+\-]/g, ''))) {
      tempErrors.phone = 'Please enter a valid 10-digit mobile number';
    }
    if (!formData.service) tempErrors.service = 'Please select your service of interest';

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      // Reset form variables
      setFormData({ name: '', phone: '', service: '', message: '' });
    }, 1100);
  };

  const SERVICES_LIST = [
    'Hair Cutting',
    'Hair Styling',
    'Beard Grooming',
    'Hair Coloring',
    'Hair Spa',
    'Facial & Skin Care',
    'Keratin Treatment',
    'Bridal & Party Makeup'
  ];

  const mapEmbedUrl = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14004.992646695287!2d77.1147814986877!3d28.652316335359746!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d03901b0f15c7%3A0x7d01cd6375bc9be1!2sBlock%20F%2C%20Rajouri%20Garden%2C%20New%20Delhi%2C%20Delhi%20110027!5e0!3m2!1sen!2sin!4v1718500000000!5m2!1sen!2sin";

  return (
    <section id="contact" className="relative py-20 sm:py-28 bg-brand-dark overflow-hidden font-sans">
      {/* Decorative Blur Backgrounds */}
      <div className="absolute bottom-0 right-1/4 h-96 w-96 rounded-full bg-gold-500/[0.02] blur-[150px] pointer-events-none" />
      <div className="absolute top-1/3 left-10 h-72 w-72 rounded-full bg-gold-400/[0.015] blur-[100px] pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="flex items-center justify-center gap-2">
            <span className="h-px w-6 bg-gold-500" />
            <span className="text-xs font-bold uppercase tracking-widest text-gold-400">PLAN YOUR VISIT</span>
            <span className="h-px w-6 bg-gold-500" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-2">
            Connect <span className="text-gold-gradient italic">With Stylists</span>
          </h2>
          <p className="text-gray-400 text-sm font-light leading-relaxed">
            Have questions or specific beauty requests? Fill out our luxury consultation form below, or drop by our lounge in Rajouri Garden directly.
          </p>
        </div>

        {/* Info & Form Fields Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start mb-20">
          
          {/* Column Left: Information Cards */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-5 space-y-6"
          >
            <div className="rounded-2xl bg-white/[0.02] border border-white/5 p-6 sm:p-8 space-y-6">
              
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-white tracking-wide border-b border-white/5 pb-4">
                Hair Zone Salon Delhi
              </h3>

              {/* Detail Address */}
              <div className="flex gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gold-500/10 text-gold-500 border border-gold-500/20">
                  <MapPin className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-sm text-white uppercase tracking-wider mb-1">
                    Studio Location
                  </h4>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    Ground Floor, F-159, Rajouri Garden, opp. DCB Bank, Block F, Rajouri Garden, Delhi, 110027
                  </p>
                </div>
              </div>

              {/* Phone */}
              <div className="flex gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gold-500/10 text-gold-500 border border-gold-500/20">
                  <Phone className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-sm text-white uppercase tracking-wider mb-1">
                    Phone Reservations
                  </h4>
                  <a
                    id="contact-call-link"
                    href="tel:09654336671"
                    className="text-lg font-semibold text-gold-400 hover:text-gold-500 transition-colors block"
                  >
                    09654336671
                  </a>
                  <span className="text-[10px] text-gray-500">Tap phone number to call directly</span>
                </div>
              </div>

              {/* Working Hours */}
              <div className="flex gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gold-500/10 text-gold-500 border border-gold-500/20">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-sm text-white uppercase tracking-wider mb-1">
                    Lounge Hours
                  </h4>
                  <ul className="text-sm text-gray-300 space-y-1">
                    <li className="flex justify-between gap-4">
                      <span>Mon - Fri:</span>
                      <span className="font-medium text-white">10:00 AM - 08:30 PM</span>
                    </li>
                    <li className="flex justify-between gap-4">
                      <span>Sat - Sun:</span>
                      <span className="font-semibold text-gold-400">09:30 AM - 09:00 PM</span>
                    </li>
                  </ul>
                </div>
              </div>

            </div>

            {/* Social Media Links Widget */}
            <div className="rounded-2xl bg-white/[0.02] border border-white/5 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="font-sans font-bold text-sm text-white">Follow Social Styling</h4>
                <p className="text-xs text-gray-400 mt-0.5">Stay updated with fresh styling trends on Delhi feeds</p>
              </div>
              <a
                id="instagram-social-placeholder"
                href="https://instagram.com/hairzonesalon"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-xl bg-white/5 border border-white/10 hover:border-gold-500/20 hover:bg-gold-500/5 px-4 py-2.5 text-xs font-semibold text-gold-500 hover:text-gold-400 transition-all group shrink-0"
              >
                <Instagram className="h-4 w-4 group-hover:scale-105 transition-transform" />
                <span>Instagram Feed</span>
              </a>
            </div>
          </motion.div>

          {/* Column Right: Validated Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-7"
          >
            <div className="rounded-3xl glass-effect border border-white/10 p-6 sm:p-10 shadow-2xl relative">
              <AnimatePresence mode="wait">
                {isSuccess ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-10 space-y-4"
                  >
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gold-500/20 text-gold-500 border border-gold-500/40">
                      <CheckCircle className="h-8 w-8 stroke-[2.5]" />
                    </div>
                    <h3 className="font-serif text-2xl font-bold text-white tracking-wide">
                      Inquiry Received!
                    </h3>
                    <p className="text-sm text-gray-300 max-w-sm mx-auto leading-relaxed">
                      Thank you for your message. Your premium inquiry code is <strong className="text-gold-400">HZ-INQ-{Math.floor(1000 + Math.random() * 9000)}</strong>. A Hair Zone consultant will phone you in 2 hours to confirm your treatment scope.
                    </p>
                    <button
                      id="reset-contact-form"
                      onClick={() => setIsSuccess(false)}
                      className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-6 py-2.5 text-xs font-semibold text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      Send Another Message
                    </button>
                  </motion.div>
                ) : (
                  <form key="form" onSubmit={handleFormSubmit} className="space-y-4 text-left">
                    
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-white tracking-wide mb-4">
                      Send Premium Inquiry
                    </h3>

                    {/* Name Input */}
                    <div>
                      <label htmlFor="contact-name" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                        Your Full Name <span className="text-gold-500">*</span>
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        required
                        className={`w-full rounded-xl bg-white/5 border ${
                          errors.name ? 'border-red-500' : 'border-white/10'
                        } px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors`}
                        placeholder="Enter your name"
                        value={formData.name}
                        onChange={(e) => {
                          setFormData({ ...formData, name: e.target.value });
                          if (errors.name) setErrors({ ...errors, name: '' });
                        }}
                      />
                      {errors.name && (
                        <p className="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                          <AlertCircle className="h-3.5 w-3.5" />
                          {errors.name}
                        </p>
                      )}
                    </div>

                    {/* Phone & Service (Grids side by side) */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Phone */}
                      <div>
                        <label htmlFor="contact-phone" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                          10-Digit Mobile No <span className="text-gold-500">*</span>
                        </label>
                        <input
                          id="contact-phone"
                          type="tel"
                          required
                          className={`w-full rounded-xl bg-white/5 border ${
                            errors.phone ? 'border-red-500' : 'border-white/10'
                          } px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors`}
                          placeholder="e.g. 9654336671"
                          value={formData.phone}
                          onChange={(e) => {
                            setFormData({ ...formData, phone: e.target.value });
                            if (errors.phone) setErrors({ ...errors, phone: '' });
                          }}
                        />
                        {errors.phone && (
                          <p className="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <AlertCircle className="h-3.5 w-3.5" />
                            {errors.phone}
                          </p>
                        )}
                      </div>

                      {/* Required Service Dropdown */}
                      <div>
                        <label htmlFor="contact-service" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                          Service Needed <span className="text-gold-500">*</span>
                        </label>
                        <select
                          id="contact-service"
                          required
                          className={`w-full rounded-xl bg-brand-gray border ${
                            errors.service ? 'border-red-500' : 'border-white/10'
                          } px-4 py-3 text-white focus:outline-none focus:border-gold-500 transition-colors`}
                          value={formData.service}
                          onChange={(e) => {
                            setFormData({ ...formData, service: e.target.value });
                            if (errors.service) setErrors({ ...errors, service: '' });
                          }}
                        >
                          <option value="" disabled>Choose service...</option>
                          {SERVICES_LIST.map((svc) => (
                            <option key={svc} value={svc}>{svc}</option>
                          ))}
                        </select>
                        {errors.service && (
                          <p className="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <AlertCircle className="h-3.5 w-3.5" />
                            {errors.service}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Message */}
                    <div>
                      <label htmlFor="contact-message" className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1.5">
                        Inquiry Message (Optional)
                      </label>
                      <textarea
                        id="contact-message"
                        rows={3}
                        className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors"
                        placeholder="Detail styling request, timing queries, hair length estimate etc..."
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      />
                    </div>

                    {/* Action Button */}
                    <button
                      id="contact-submit-btn"
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gold-500 hover:bg-gold-600 px-6 py-4 font-serif text-sm font-bold uppercase tracking-wider text-black bg-gold-gradient transition-all cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <span className="h-4 w-4 animate-spin rounded-full border-2 border-black border-t-transparent" />
                          <span>Dispatching Inquiry...</span>
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 fill-black text-black" />
                          <span>Send Premium Inquiry</span>
                        </>
                      )}
                    </button>

                  </form>
                )}
              </AnimatePresence>
            </div>
          </motion.div>

        </div>

        {/* 11. GOOGLE MAPS SECTION */}
        <div id="google-maps-container" className="space-y-4">
          <h3 className="font-serif text-lg sm:text-xl font-bold text-center text-white flex items-center justify-center gap-2">
            <Sparkles className="h-4 w-4 text-gold-500" />
            Live Directions to Rajouri Garden Lounge
          </h3>
          <div className="overflow-hidden rounded-2xl border border-white/15 h-96 sm:h-[420px] w-full shadow-2xl relative group bg-brand-gray">
            <iframe
              src={mapEmbedUrl}
              width="100%"
              height="100%"
              style={{ border: 0, filter: 'grayscale(1) invert(0.9) contrast(1.2)' }} // elegant gold/contrast dark theme mapping
              allowFullScreen={true}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Hair Zone Salon Locations Map in Rajouri Garden Delhi"
              className="absolute inset-0 h-full w-full opacity-80 group-hover:opacity-100 transition-opacity duration-300 pointer-events-auto"
            />
          </div>
        </div>

      </div>
    </section>
  );
}
