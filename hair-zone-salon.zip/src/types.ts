export interface Service {
  id: string;
  title: string;
  category: 'styling' | 'treatments' | 'makeup' | 'grooming' | 'all';
  price: string;
  duration: string;
  description: string;
  image: string;
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  text: string;
  role: string;
  image: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  image: string;
  category: 'haircuts' | 'coloring' | 'makeup' | 'styling';
}

export interface BookingFormInput {
  name: string;
  phone: string;
  service: string;
  date: string;
  time: string;
  message?: string;
}
