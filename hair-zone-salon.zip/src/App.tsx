import React, { useState, useEffect } from 'react';
import { ChevronUp } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Stats from './components/Stats';
import About from './components/About';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Gallery from './components/Gallery';
import Reviews from './components/Reviews';
import CTA from './components/CTA';
import Contact from './components/Contact';
import Footer from './components/Footer';
import BookingModal from './components/BookingModal';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [preselectedService, setPreselectedService] = useState<string | undefined>(undefined);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Monitor scroll for Scroll-to-Top helper button
  useEffect(() => {
    const handleScrollVisibility = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };

    window.addEventListener('scroll', handleScrollVisibility);
    return () => window.removeEventListener('scroll', handleScrollVisibility);
  }, []);

  const handleOpenBooking = (serviceName?: string) => {
    setPreselectedService(serviceName);
    setIsBookingOpen(true);
  };

  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className="relative min-h-screen bg-brand-dark text-white select-none">
      {/* 1. Sticky Navigation Bar */}
      <Navbar onOpenBooking={handleOpenBooking} />

      {/* Main Sections */}
      <main>
        {/* 2. Hero Section */}
        <Hero onOpenBooking={() => handleOpenBooking()} />

        {/* 3. Trust & Statistics Section */}
        <Stats />

        {/* 4. About Us Section */}
        <About onOpenBooking={() => handleOpenBooking()} />

        {/* 5. Services Section */}
        <Services onOpenBooking={handleOpenBooking} />

        {/* 6. Why Choose Us Section */}
        <WhyChooseUs />

        {/* 7. Salon Gallery */}
        <Gallery />

        {/* 8. Customer Reviews Section */}
        <Reviews />

        {/* 9. Call-To-Action (CTA) Section */}
        <CTA onOpenBooking={() => handleOpenBooking()} />

        {/* 10. Contact Section & 11. Google Maps Location Section */}
        <Contact />
      </main>

      {/* 12. Footer */}
      <Footer onOpenBooking={() => handleOpenBooking()} />

      {/* Interactive Booking Popup modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        preselectedService={preselectedService}
      />

      {/* Floating Action Button: Scroll to Top */}
      {showScrollTop && (
        <button
          id="scroll-to-top-btn"
          onClick={handleScrollToTop}
          className="fixed bottom-6 right-6 z-30 flex h-12 w-12 items-center justify-center rounded-xl bg-gold-500 border border-gold-600 text-black hover:bg-gold-600 transition-all shadow-xl hover:-translate-y-1 cursor-pointer active:scale-95 bg-gold-gradient"
          aria-label="Scroll to top of salon website"
        >
          <ChevronUp className="h-6 w-6 stroke-[2.5]" />
        </button>
      )}
    </div>
  );
}
